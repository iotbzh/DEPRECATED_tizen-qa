<?php
    echo "id:";
    echo $_POST["id"];
    echo ";";
    echo "value:";
    echo $_POST["value"];
    echo ";";
?>
