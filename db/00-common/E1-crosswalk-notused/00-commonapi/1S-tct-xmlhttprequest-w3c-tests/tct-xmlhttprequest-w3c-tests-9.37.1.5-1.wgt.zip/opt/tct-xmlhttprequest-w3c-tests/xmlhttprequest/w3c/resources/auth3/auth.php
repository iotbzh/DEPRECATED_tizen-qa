<?php
// we want different directories to give the browser the impression that we have different realms,
// but actually we don't really want to duplicate the backend scripts.. so..
require('../auth1/auth.php')
?>