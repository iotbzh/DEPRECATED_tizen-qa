runTestRequests([ SyncRequestSettingTimeoutAfterOpen,
		  SyncRequestSettingTimeoutBeforeOpen ]);
