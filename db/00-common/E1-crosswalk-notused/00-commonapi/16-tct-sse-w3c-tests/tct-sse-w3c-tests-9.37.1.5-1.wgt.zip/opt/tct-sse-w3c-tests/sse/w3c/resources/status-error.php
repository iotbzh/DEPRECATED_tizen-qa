<?php
  $status = $_GET["status"] ? $_GET["status"] : "404";
  header("HTTP/1.1 " . $status . " HAHAHAHA");
  header("Content-Type: text/event-stream");
  echo "data: data\n\n";
?>
